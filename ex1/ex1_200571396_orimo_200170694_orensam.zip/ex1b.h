//
//  ex1b.h
//  cg-projects
//
//  Created by HUJI Computer Graphics course staff, 2013.
//

#ifndef __ex1b__ex1b__
#define __ex1b__ex1b__

#include <iostream>

#endif /* defined(__ex1b__ex1b__) */
