//
//  ex1a.h
//  cg-projects
//
//  Created by HUJI Computer Graphics course staff, 2013.
//

#ifndef __ex1a__ex1a__
#define __ex1a__ex1a__

#include <iostream>

#endif /* defined(__ex1a__ex1a__) */
