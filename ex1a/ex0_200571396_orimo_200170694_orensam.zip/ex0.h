//
//  ex0.h
//  cg-projects
//
//  Created by HUJI Computer Graphics course staff, 2013.
//

#ifndef __ex0__ex0__
#define __ex0__ex0__

#include <iostream>

#endif /* defined(__ex0__ex0__) */
